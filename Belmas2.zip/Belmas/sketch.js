function setup() {
  createCanvas(450, 450);
}

function draw() {
  background(220);
  enemy(50, 250);
  for (y = mouseY; y < height - 100; y += 1) {
    bullet(50, y - 100);
  }
}

function enemy(x, y) {
  push();
  translate(x, y);
  stroke(0,0,120);
  strokeWeight(70);
  rect(28, 20, 50, 10);
  scale(0.5, 1.5);
  rect(95, 10, 20, 0.1);
  pop();
}
function bullet(x, y) {
  push();
  translate(x, y);
  angleMode(DEGREES);
  fill(255,0,0);
  stroke(255,0,0);
  strokeWeight(1);
  rotate(5);
  rect(85, 170, 10, 25);
  pop();
}