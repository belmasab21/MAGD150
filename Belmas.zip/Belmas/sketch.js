function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(209);
  colorMode(RGB, 255, 255, 255, 1);
  
  triangle(40, 80, 50, 70, 60, 80);
  fill('red');
  
  arc(50, 40, 30, 30, 0, 2*PI);
  fill('yellow');
  
  line(50, 70, 50, 55);
  
  quad(30, 80, 80, 80, 80, 100, 30, 100);
  fill('green');
  
  arc(35, 105, 10, 10, 0, 2*PI);
  arc(75, 105, 10, 10, 0, 2*PI);
  fill('blue');
}