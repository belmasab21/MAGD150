function setup() {
  createCanvas(400, 400);
  x = width / 2;
  y = height;
  value = 0;
  value1 = 0;
}

function draw() {
  background(220);
  
  stroke(50);
  fill(value);
  ellipse(x, y, 25, 25);
  x = x + random(-1, 1);
  y = y - 1;
  
  
  stroke(50);
  fill(value1);
  rect(350, 30, 350, 50);
  if (keyIsPressed == true) {
    value1 = 255;
  }
}
function mouseClicked() {
  if (value == 0) {
    value = 255;
  } else {
    value = 0;
  }

}